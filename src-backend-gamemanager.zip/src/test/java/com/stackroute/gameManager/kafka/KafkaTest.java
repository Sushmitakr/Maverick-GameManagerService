/*package com.stackroute.gameManager.kafka;

import static org.junit.Assert.*;

import org.apache.kafka.clients.producer.internals.Sender;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class KafkaTest {
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void test() {
		
	}

}
*/