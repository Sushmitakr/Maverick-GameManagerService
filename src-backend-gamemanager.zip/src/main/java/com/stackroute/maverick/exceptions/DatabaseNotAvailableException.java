package com.stackroute.maverick.exceptions;

@SuppressWarnings("serial")
public class DatabaseNotAvailableException extends Exception {

	public DatabaseNotAvailableException() {
		super();
	}

	public DatabaseNotAvailableException(String message) {
		super(message);

	}

	/*public void handleUserNotFoundException() {

	}*/
}
