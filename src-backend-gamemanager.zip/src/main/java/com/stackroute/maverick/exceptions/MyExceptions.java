package com.stackroute.maverick.exceptions;

@SuppressWarnings("serial")
public class MyExceptions extends Exception{

public MyExceptions() {
		
		super();
	
	}

	public MyExceptions(String msg) {
		
		super(msg);
		
	}
}
